# L1 and L2 Regularization Implementation
import numpy as np
import pandas as pd

# 1. Sample Dataset
X = np.array([
    [0.5, 1.2, 0.05],
    [1.0, 2.4, 0.12],
    [1.5, 3.1, 0.88],
    [2.0, 4.5, 0.22]
])
y = np.array([10.2, 20.5, 29.8, 41.0])
feature_names = ['X1', 'X2', 'X3']

# 2. Standardize Features
X_mean = X.mean(axis=0)
X_std = X.std(axis=0)
Z = (X - X_mean) / X_std
y_mean = y.mean()
yc = y - y_mean

# 3. L1 Regularization (LASSO)
def l1_regularization(X, y, lam, iterations=10000):
    n, p = X.shape
    weights = np.zeros(p)
    for _ in range(iterations):
        old_weights = weights.copy()
        for j in range(p):
            residual = y - X @ weights + X[:, j] * weights[j]
            rho = np.mean(X[:, j] * residual)
            if rho > lam:
                weights[j] = rho - lam
            elif rho < -lam:
                weights[j] = rho + lam
            else:
                weights[j] = 0.0
        if np.max(np.abs(weights - old_weights)) < 1e-12:
            break
    return weights

# 4. L2 Regularization (Ridge)
def l2_regularization(X, y, lam):
    n = X.shape[0]
    identity = np.eye(X.shape[1])
    weights = np.linalg.solve(
        (X.T @ X) / n + 2 * lam * identity,
        (X.T @ y) / n
    )
    return weights
