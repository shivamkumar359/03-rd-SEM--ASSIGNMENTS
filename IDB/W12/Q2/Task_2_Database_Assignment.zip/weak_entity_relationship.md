
TASK 2: WEAK ENTITY RELATIONSHIP DIAGRAM

             EMPLOYEE
        +------------------+
        | Ssn (Primary Key)|
        +------------------+
                 |
                 |
          Identifying
          Relationship
                 |
                 |
              DEPENDENT
       +-----------------------+
       | Essn (Foreign Key)    |
       | Dependent_name        |
       | Sex                   |
       | Birth_date            |
       | Relationship          |
       +-----------------------+

COMPOSITE PRIMARY KEY:
(Essn, Dependent_name)


RELATIONSHIP DESCRIPTION:

EMPLOYEE (1) -------- (N) DEPENDENT

One employee can have multiple dependents.
Each dependent must belong to exactly one employee.

Essn in DEPENDENT references Ssn in EMPLOYEE.

If an employee is deleted, their dependent records
are automatically deleted using ON DELETE CASCADE.
