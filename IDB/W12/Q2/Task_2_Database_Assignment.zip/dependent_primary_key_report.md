
PRIMARY KEY JUSTIFICATION REPORT

The DEPENDENT table uses a composite primary key consisting
of Essn and Dependent_name. Essn identifies the employee
who owns the dependent, while Dependent_name acts as the
partial key of the weak entity. Together, they uniquely
identify each dependent. Essn also serves as a foreign key
referencing EMPLOYEE(Ssn), establishing referential
integrity and existence dependency. This design allows
different employees to have dependents with identical
names while preventing duplicate dependent names for
the same employee.
