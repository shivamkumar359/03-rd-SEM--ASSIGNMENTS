
-- TASK 2: IMPLEMENTING WEAK ENTITY RELATIONSHIPS

-- Create the strong entity EMPLOYEE
CREATE TABLE EMPLOYEE (
    Ssn VARCHAR(20) PRIMARY KEY
);

-- Create the weak entity DEPENDENT
CREATE TABLE DEPENDENT (
    Essn VARCHAR(20) NOT NULL,
    Dependent_name VARCHAR(100) NOT NULL,
    Sex VARCHAR(10),
    Birth_date DATE,
    Relationship VARCHAR(50),

    PRIMARY KEY (Essn, Dependent_name),

    FOREIGN KEY (Essn)
        REFERENCES EMPLOYEE(Ssn)
        ON DELETE CASCADE
);

-- Insert sample employee records
INSERT INTO EMPLOYEE (Ssn)
VALUES
('EMP001'),
('EMP002'),
('EMP003');

-- Insert sample dependent records
INSERT INTO DEPENDENT
(Essn, Dependent_name, Sex, Birth_date, Relationship)
VALUES
('EMP001', 'Rahul', 'Male', '2010-05-15', 'Son'),
('EMP001', 'Priya', 'Female', '2012-08-20', 'Daughter'),
('EMP002', 'Amit', 'Male', '2008-03-10', 'Son'),
('EMP003', 'Neha', 'Female', '2015-11-25', 'Daughter');

-- Display employee records
SELECT * FROM EMPLOYEE;

-- Display dependent records
SELECT * FROM DEPENDENT;

-- Display employees with their dependents
SELECT
    E.Ssn,
    D.Dependent_name,
    D.Sex,
    D.Birth_date,
    D.Relationship
FROM EMPLOYEE E
JOIN DEPENDENT D
ON E.Ssn = D.Essn;
