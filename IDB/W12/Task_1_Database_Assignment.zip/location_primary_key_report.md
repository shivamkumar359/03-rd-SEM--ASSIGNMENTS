
PRIMARY KEY JUSTIFICATION REPORT

The DEPT_LOCATIONS table uses a composite primary key
consisting of Dnumber and Dlocation. Dnumber identifies
the department, while Dlocation identifies a particular
location associated with that department. Together, these
attributes uniquely identify each department-location
combination. This design allows one department to have
multiple locations while preventing duplicate location
entries for the same department. Additionally, Dnumber
acts as a foreign key referencing the DEPARTMENT table,
maintaining referential integrity between both relations.
