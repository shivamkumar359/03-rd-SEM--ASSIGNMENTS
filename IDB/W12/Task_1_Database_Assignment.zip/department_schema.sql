
-- TASK 1: Mapping Strong Entities and Multivalued Attributes

-- Create the strong entity table
CREATE TABLE DEPARTMENT (
    Dnumber INT PRIMARY KEY
);

-- Create a separate table for the multivalued Location attribute
CREATE TABLE DEPT_LOCATIONS (
    Dnumber INT NOT NULL,
    Dlocation VARCHAR(100) NOT NULL,

    PRIMARY KEY (Dnumber, Dlocation),

    FOREIGN KEY (Dnumber)
        REFERENCES DEPARTMENT(Dnumber)
        ON DELETE CASCADE
);

-- Example data insertion

INSERT INTO DEPARTMENT (Dnumber)
VALUES (1), (2), (3);

INSERT INTO DEPT_LOCATIONS (Dnumber, Dlocation)
VALUES
(1, 'Mumbai'),
(1, 'Delhi'),
(2, 'Bangalore'),
(2, 'Pune'),
(3, 'Hyderabad');

-- Display department records
SELECT * FROM DEPARTMENT;

-- Display department locations
SELECT * FROM DEPT_LOCATIONS;

-- Display departments with their locations
SELECT
    D.Dnumber,
    L.Dlocation
FROM DEPARTMENT D
JOIN DEPT_LOCATIONS L
ON D.Dnumber = L.Dnumber;
